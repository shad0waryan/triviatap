export const questions = [
    {
        prompt:"What is the color of the sky",
        optionA: "Red",
        optionB: "Green",
        optionC: "Blue",
        optionD: "Yellow",
        answer: "C",

    },
    {
        prompt:"How many zeroes are there in a Million?",
        optionA: "6",
        optionB: "10",
        optionC: "3",
        optionD: "7",
        answer: "A",

    },
    {
        prompt:"What is the full form of CPU??",
        optionA: "Computer Processing Unit",
        optionB: "Central Processing Unit",
        optionC: "Computer Principle Unit",
        optionD: "Control Processing Unit",
        answer: "B",

    },
    {
        prompt:"The list of coded instructions is called?",
        optionA: "Utility Program",
        optionB: "FlowChart",
        optionC: "Algorithm",
        optionD: "Computer Program",
        answer: "D",

    },

];